
create database shoppingBasket;
use shoppingBasket;

create table user (email varchar(255) not null,name varchar(255),address varchar(255), primary key (email));
select * from user;
DROP TABLE product;
 create table product (model integer not null,item_name varchar(255),  item_type varchar(255),
 unit_price float not null,sales_tax float not null,  import_tax float not null,  primary key (model));
 desc invoice;
 DROP TABLE cart;
 create table cart (cart_id integer not null, email varchar(255),name varchar(255),address varchar(255), item_name varchar(255),
 model integer not null, price float not null, quantity integer not null, primary key (cart_id));
select * from cart;

DROP TABLE invoice; 
create table invoice (invoice_id integer not null, address varchar(255), email varchar(255), item_name varchar(255), 
name varchar(255), sub_tax float, sub_total float, primary key (invoice_id));
 
 #inserting values
 desc product;
 select * from product;
INSERT INTO PRODUCT VALUES(1001,"Samsung TV","TV",55000,0,0);
INSERT INTO PRODUCT VALUES(1002,"One Plus TV","TV",35000,0,0);
INSERT INTO PRODUCT VALUES(1003,"Sony TV","TV",75000,0,0);
INSERT INTO PRODUCT VALUES(1004,"MI TV","TV",45000,0,0);
INSERT INTO PRODUCT VALUES(1005,"LG TV","TV",29000,0,0);


INSERT INTO PRODUCT VALUES(1011,"Apple","MOBILE",112000,10,5);
INSERT INTO PRODUCT VALUES(1012,"Real Me","MOBILE",25000,10,5);
INSERT INTO PRODUCT VALUES(1013,"Samsung","MOBILE",45000,10,5);
INSERT INTO PRODUCT VALUES(1014,"One Plus","MOBILE",55000,10,5);
INSERT INTO PRODUCT VALUES(1015,"Vivo","MOBILE",31000,10,5);

INSERT INTO PRODUCT VALUES(1021,"HP Pendrive","PENDRIVE",1920,10,0);
INSERT INTO PRODUCT VALUES(1022,"Sandisk Pendrive","PENDRIVE",900,10,0);
INSERT INTO PRODUCT VALUES(1023,"Sony Pendrive","PENDRIVE",1500,10,0);
INSERT INTO PRODUCT VALUES(1024,"Toshiba Pendrive","PENDRIVE",1300,10,0);
INSERT INTO PRODUCT VALUES(1025,"Dell Pendrive","PENDRIVE",2120,10,0);

