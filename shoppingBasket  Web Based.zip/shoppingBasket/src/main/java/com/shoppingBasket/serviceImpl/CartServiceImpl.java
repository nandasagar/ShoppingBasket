package com.shoppingBasket.serviceImpl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;
import com.shoppingBasket.model.Cart;
import com.shoppingBasket.model.Product;
import com.shoppingBasket.model.User;
import com.shoppingBasket.repository.CartRepository;
import com.shoppingBasket.repository.ProductRepository;
import com.shoppingBasket.repository.UserRepository;
import com.shoppingBasket.service.CartService;

/**
 * @author Nanda sagar
 *
 */
@Service
@Transactional
public class CartServiceImpl implements CartService {

	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private ProductServiceImpl productServiceImpl;
	@Autowired
	private CartRepository cartRepository;
	@Autowired
	private UserRepository userRepository;

	/**
	 * save cart Details Added by the User
	 * 
	 * @param cart
	 * @param model
	 * @return
	 */
	@Override
	public ModelAndView saveToCart(int model, String email) {
		ModelAndView pageView = new ModelAndView("cart");
		try {
			Optional<Product> product = productRepository.findById(model);
			Optional<User> user = userRepository.findById(email);
			List<Cart> cartList = cartRepository.findAllByEmailAndModel(email, model);
			int quantity = 1;
			for (var cart : cartList) {
				if (cart.getModel() == model) {
					quantity = cart.getQuantity() + 1;
					Cart getCart = cartRepository.getById(cart.getCartId());
					getCart.setQuantity(quantity);
					getCart.setPrice(quantity * product.get().getUnitPrice());
					cartRepository.save(getCart);
				}
			}
			if (cartList.isEmpty()) {
				Cart newCart = new Cart(email, user.get().getName(), user.get().getAddress(), model,
						product.get().getItemName(), quantity, product.get().getUnitPrice());
				cartRepository.save(newCart);
			}
			List<Cart> latestCart = cartRepository.findAllByEmail(email);
			System.out.println("cart list is :" + latestCart);
			pageView.addObject("user", email);
			pageView.addObject("name", user.get().getName());
			pageView.addObject("list", latestCart);
		} catch (Exception exception) {
			System.out.printf(" Exception caught in cart ServiceImpl", exception.getMessage());
		}
		return pageView;
	}

	/**
	 * Deleting the item from the Cart based on User Choice
	 * 
	 * @param cartId
	 * @return
	 */
	@Override
	public ModelAndView removeCartItem(int cartId) {

		ModelAndView pageView = new ModelAndView("cart");
		try {
			System.out.println("Hii From Removing Cart ");
			Cart getCart = cartRepository.getById(cartId);
			String email = getCart.getEmail();
			String name = getCart.getName();
			if (Objects.nonNull(getCart))
				;
			cartRepository.delete(getCart);
			List<Cart> latestCart = cartRepository.findAllByEmail(email);
			pageView.addObject("name", name);
			pageView.addObject("user", email);
			pageView.addObject("list", latestCart);
		} catch (Exception exception) {
			System.out.printf(" Exception caught in cart ServiceImpl", exception.getMessage());
		}
		return pageView;
	}

	/**
	 * Update quantity of the product based on User Choice
	 * 
	 * @param quantity
	 * @param cartId
	 * @return
	 */
	@Override
	public ModelAndView updateCart(int cartId, int quantity) {

		ModelAndView pageView = new ModelAndView("cart");
		try {
			System.out.println("Hii From Updating Cart quantity is " + quantity);
			Cart getCart = cartRepository.getById(cartId);
			String email = null;
			String name = null;
			List<Cart> latestCart = null;
			Optional<Product> product = productRepository.findById(getCart.getModel());
			if (Objects.nonNull(getCart)) {
				getCart.setQuantity(quantity);
				getCart.setPrice(quantity * product.get().getUnitPrice());
				cartRepository.save(getCart);
				email = getCart.getEmail();
				name = getCart.getName();
			}
			if (Objects.nonNull(email))
				latestCart = cartRepository.findAllByEmail(email);
			pageView.addObject("name", name);
			pageView.addObject("user", email);
			pageView.addObject("list", latestCart);
		} catch (Exception exception) {
			System.out.printf(" Exception caught in cart ServiceImpl", exception.getMessage());
		}
		return pageView;
	}

	@Override
	public ModelAndView viewCart(int cartId) {

		ModelAndView pageView = new ModelAndView("cart");
		try {
			Cart getCart = cartRepository.getById(cartId);
			String email = getCart.getEmail();
			String name = getCart.getName();
			if (Objects.nonNull(getCart))
				;
			List<Cart> latestCart = cartRepository.findAllByEmail(email);
			pageView.addObject("name", name);
			pageView.addObject("user", email);
			pageView.addObject("error", "*Only Possitive Numbers are Accepted");
			pageView.addObject("list", latestCart);
		} catch (Exception exception) {
			System.out.printf(" Exception caught in cart ServiceImpl", exception.getMessage());
		}
		return pageView;
	}

	/**
	 * Fetching my cart details of the User
	 * 
	 * @param email
	 * @return
	 */
	@Override
	public ModelAndView getMyCart(String email) {

		ModelAndView pageView = new ModelAndView("cart");
		try {
			List<Cart> latestCart = cartRepository.findAllByEmail(email);
			Cart cart = cartRepository.getByEmail(email);
			User user = userRepository.getById(email);
			if (Objects.isNull(cart)) {
				return productServiceImpl.getAllProducts(user, email);
			}
			pageView.addObject("user", email);
			pageView.addObject("name", user.getName());
			pageView.addObject("error", "*Only Possitive Numbers are Accepted");
			pageView.addObject("list", latestCart);
		} catch (Exception exception) {
			System.out.printf(" Exception caught in cart ServiceImpl", exception.getMessage());
		}
		return pageView;
	}

}
