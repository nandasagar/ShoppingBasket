package com.shoppingBasket.serviceImpl;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;
import com.shoppingBasket.model.Product;
import com.shoppingBasket.model.User;
import com.shoppingBasket.repository.ProductRepository;
import com.shoppingBasket.service.ProductService;

/**
 * @author Nanda sagar
 *
 */
@Service
@Transactional
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepository;

	/**
	 * get All Product Lists
	 */
	@Override
	public ModelAndView getAllProducts(User user, String email) {

		ModelAndView pageView = new ModelAndView("products");
		try {
			List<Product> products = productRepository.findAll();
			pageView.addObject("list", products);
			pageView.addObject("user", email);
			pageView.addObject("name", user.getName());
			pageView.addObject("error", "MyCart is Avaiable Once you Add a product");
			System.out.println("Products List are " + products);
		} catch (Exception exception) {
			System.out.printf(" Exception caught in product ServiceImpl", exception.getMessage());
		}
		return pageView;
	}

}
