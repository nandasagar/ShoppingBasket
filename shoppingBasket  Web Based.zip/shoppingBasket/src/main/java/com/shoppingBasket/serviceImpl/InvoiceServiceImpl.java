package com.shoppingBasket.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;
import com.shoppingBasket.model.Cart;
import com.shoppingBasket.model.Invoice;
import com.shoppingBasket.model.Product;
import com.shoppingBasket.repository.CartRepository;
import com.shoppingBasket.repository.InvoiceRepository;
import com.shoppingBasket.repository.ProductRepository;
import com.shoppingBasket.service.InvoiceService;

/**
 * @author Nanda sagar
 *
 */
@Service
@Transactional
public class InvoiceServiceImpl implements InvoiceService {

	@Autowired
	InvoiceRepository invoiceRepository;
	@Autowired
	CartRepository cartRepository;
	@Autowired
	CartServiceImpl cartServiceImpl;
	@Autowired
	private ProductRepository productRepository;

	/**
	 * Calculation of Tax and Grand Total returns Invoice Data Including Grand Total
	 * and Total tax
	 * 
	 * Generating the Invoice Bill for the My cart Details
	 * 
	 * @param email
	 * @return
	 */
	@Override
	public ModelAndView generateInvoice(String email) {
		// TODO Auto-generated method stub
		ModelAndView modelView = new ModelAndView("invoice");
		try {
			List<Cart> latestCart = cartRepository.findAllByEmail(email);
			if (latestCart.isEmpty()) {
				return cartServiceImpl.getMyCart(email);
			}
			String name = " ";
			String address = " ";
			int cartSize = latestCart.size();
			float grandTotal = 0;
			float totalTax = 0;
			for (var cart : latestCart) {
				Invoice invoice = new Invoice();
				Product product = productRepository.getById(cart.getModel());
				float price = cart.getPrice();
				float salesTax = product.getSalesTax();
				float importTax = product.getImportTax();
				invoice.setItemName(cart.getItemName());
				invoice.setEmail(cart.getEmail());
				invoice.setName(cart.getName());
				invoice.setAddress(cart.getAddress());
				invoice.setSubTotal((price * salesTax + price * importTax + 100 * price) / 100);
				invoice.setSubTax((price * salesTax + price * importTax) / 100);
				Invoice savedInvoice = invoiceRepository.save(invoice);
				grandTotal = grandTotal + savedInvoice.getSubTotal();
				totalTax = totalTax + savedInvoice.getSubTax();
				System.out.println("invoice Generated Successfully " + savedInvoice);
				cartRepository.deleteById(cart.getCartId());
				name = savedInvoice.getName();
				address = savedInvoice.getAddress();
			}
			List<Invoice> listInvoice = invoiceRepository.findAllByEmail(email);
			List<Invoice> listValue = new ArrayList<Invoice>();
			int invoiceSize = listInvoice.size();
			int i = invoiceSize - 1;
			while (cartSize != 0) {
				listValue.add(listInvoice.get(i));
				cartSize--;
				i--;
			}
			modelView.addObject("list", listValue);
			modelView.addObject("user", email);
			modelView.addObject("name", name);
			modelView.addObject("address", address);
			modelView.addObject("grandTotal", grandTotal);
			modelView.addObject("totalTax", totalTax);
		} catch (Exception exception) {
			System.out.printf(" Exception caught in Invoice ServiceImpl", exception.getMessage());
		}
		return modelView;
	}

}
