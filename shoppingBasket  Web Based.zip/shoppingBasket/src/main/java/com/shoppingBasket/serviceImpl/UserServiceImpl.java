package com.shoppingBasket.serviceImpl;

import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.shoppingBasket.model.User;
import com.shoppingBasket.repository.UserRepository;
import com.shoppingBasket.service.UserService;

/**
 * @author Nanda sagar
 *
 */
@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private ProductServiceImpl productServiceImpl;

	/**
	 * validate user
	 * Checking User data already Present in DB Before Saving user info.
	 */
	@Override
	public ModelAndView checkUser(User user, HttpServletRequest request) {
		// TODO Auto-generated method stub
		ModelAndView mode = new ModelAndView("home");
		try {
		if (Objects.isNull(user.getEmail()) || Objects.isNull(user.getName()) || Objects.isNull(user.getAddress())) {
			mode.addObject("message", "Enter Valid Details");
			return mode;
		}
		String email = user.getEmail();
		String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		User checkUser = userRepository.findByEmail(user.getEmail());
		if (Objects.nonNull(checkUser)) {
			if (checkUser.getEmail().equalsIgnoreCase(user.getEmail())) {
				HttpSession session = request.getSession();
				session.setMaxInactiveInterval(900000);
				return productServiceImpl.getAllProducts(user, user.getEmail());
			}
		} else {
			if (email.matches(regex) && Objects.nonNull(user.getName()) && Objects.nonNull(user.getAddress())) {
				userRepository.save(user);
				HttpSession session = request.getSession();
				session.setMaxInactiveInterval(9000000);
				return productServiceImpl.getAllProducts(user, user.getEmail());
			}
		}
		mode.addObject("user", user);
		}catch (Exception exception) {
			System.out.printf(" Exception caught in user ServiceImpl", exception.getMessage());
		}return mode;
	}

}
