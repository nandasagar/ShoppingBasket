package com.shoppingBasket.service;

import org.springframework.web.servlet.ModelAndView;

/**
 * @author Nanda sagar
 *
 */
public interface InvoiceService {
	public ModelAndView generateInvoice(String email);

}
