package com.shoppingBasket.service;

import org.springframework.web.servlet.ModelAndView;

/**
 * @author Nanda sagar
 *
 */
public interface CartService {

	public ModelAndView saveToCart(int model, String email);

	public ModelAndView removeCartItem(int cartId);

	public ModelAndView updateCart(int cartId, int quantity);

	public ModelAndView viewCart(int cartId);

	public ModelAndView getMyCart(String email);
}
