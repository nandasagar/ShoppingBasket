package com.shoppingBasket.service;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.servlet.ModelAndView;

import com.shoppingBasket.model.User;
/**
 * @author Nanda sagar
 *
 */
public interface UserService {

	public ModelAndView checkUser(User user, HttpServletRequest request);

}
