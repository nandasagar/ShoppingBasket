package com.shoppingBasket.service;

import org.springframework.web.servlet.ModelAndView;

import com.shoppingBasket.model.User;

/**
 * @author Nanda sagar
 *
 */
public interface ProductService {


	public ModelAndView getAllProducts(User user, String email);
}
