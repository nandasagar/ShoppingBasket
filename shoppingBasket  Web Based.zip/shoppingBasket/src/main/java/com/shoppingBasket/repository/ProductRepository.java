package com.shoppingBasket.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.shoppingBasket.model.Product;
/**
 * @author Nanda sagar
 *
 */
@EnableJpaRepositories
public interface ProductRepository extends JpaRepository<Product,Integer> {

	
}
