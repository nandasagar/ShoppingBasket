package com.shoppingBasket.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.shoppingBasket.model.User;
/**
 * @author Nanda sagar
 *
 */
@EnableJpaRepositories
public interface UserRepository extends JpaRepository<User, String> {

	User findByEmail(String email);

}
