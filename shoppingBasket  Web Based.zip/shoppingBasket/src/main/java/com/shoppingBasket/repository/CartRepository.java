package com.shoppingBasket.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.shoppingBasket.model.Cart;
/**
 * @author Nanda sagar
 *
 */
@EnableJpaRepositories
public interface CartRepository extends JpaRepository<Cart, Integer> {

	List<Cart> findAllByEmail(String email);

	List<Cart> findAllByEmailAndModel(String email, int model);

	Cart getByEmail(String email);

}
