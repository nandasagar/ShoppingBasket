package com.shoppingBasket.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.shoppingBasket.model.Invoice;
/**
 * @author Nanda sagar
 *
 */
@EnableJpaRepositories
public interface InvoiceRepository extends JpaRepository<Invoice, Integer> {

	List<Invoice> findAllByEmail(String email);

}
