package com.shoppingBasket.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Product")
public class Product {

	@Id
	@Column(name="model")
	private int model;
	@Column(name="item_name")
	private String itemName;
	@Column(name="item_type")
	private String itemType;
	@Column(name="unit_Price")
	private float unitPrice;
	@Column(name="import_tax")
	private float importTax;
	@Column(name="sales_tax")
	private float salesTax;
	public int getModel() {
		return model;
	}
	public void setModel(int model) {
		this.model = model;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public float getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(float unitPrice) {
		this.unitPrice = unitPrice;
	}
	public float getImportTax() {
		return importTax;
	}
	public void setImportTax(float importTax) {
		this.importTax = importTax;
	}
	public float getSalesTax() {
		return salesTax;
	}
	public void setSalesTax(float salesTax) {
		this.salesTax = salesTax;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Product(int model, String itemName, String itemType, float unitPrice, float importTax, float salesTax) {
		super();
		this.model = model;
		this.itemName = itemName;
		this.itemType = itemType;
		this.unitPrice = unitPrice;
		this.importTax = importTax;
		this.salesTax = salesTax;
	}
	@Override
	public String toString() {
		return "Product [model=" + model + ", itemName=" + itemName + ", itemType=" + itemType + ", unitPrice="
				+ unitPrice + ", importTax=" + importTax + ", salesTax=" + salesTax + "]";
	}


	
}
