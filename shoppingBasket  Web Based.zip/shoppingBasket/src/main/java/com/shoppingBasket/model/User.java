package com.shoppingBasket.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;



@Entity
@Table(name="user")
public class User implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3612340495301768238L;
	@Id
	@NotBlank(message="Email is Required")
	@Email(message="Invalid email!. Try Again")
	@Column(name="email")
	private String email;
	@Column(name="name")
	@NotBlank(message="name is Required")
	private String name;
	@Column(name="address")
	@Size(min=4 ,max=100, message="Address should be atleast 5 char. Try Again")
	@NotBlank(message="address is Required")
	private String address;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String fullName) {
		this.name = fullName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @param email
	 * @param fullName
	 * @param address
	 */
	public User(String email, String fullName, String address) {
		super();
		this.email = email;
		this.name = fullName;
		this.address = address;
	}
	/**
	 * 
	 */
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "User [email=" + email + ", name=" + name + ", address=" + address + "]";
	}
	
	
	
}
