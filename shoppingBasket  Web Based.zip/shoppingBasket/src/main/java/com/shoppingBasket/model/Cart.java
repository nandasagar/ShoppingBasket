package com.shoppingBasket.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Positive;
/**
 * @author Nanda sagar
 *
 */
@Entity
@Table(name = "cart")
public class Cart implements Serializable {

	private static final long serialVersionUID = -6542315806800268755L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "cart_id", unique = true, nullable = false)
	private int cartId;
	@Column(name = "email")
	private String email;
	@Column(name = "name")
	private String name;
	@Column(name = "address")
	private String address;
	@Column(name = "model")
	private int model;
	@Column(name = "item_name")
	private String itemName;
	@Column(name = "quantity")
	@Positive
	private int quantity;
	@Column(name = "price")
	private float price;

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public int getModel() {
		return model;
	}

	public void setModel(int model) {
		this.model = model;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param email
	 * @param name
	 * @param address
	 * @param model
	 * @param itemName
	 * @param quantity
	 * @param price
	 */
	public Cart(int cartId, String email, String name, String address, int model, String itemName, int quantity,
			float price) {
		super();
		this.cartId = cartId;
		this.email = email;
		this.name = name;
		this.address = address;
		this.model = model;
		this.itemName = itemName;
		this.quantity = quantity;
		this.price = price;
	}

	/**
	 * @param email
	 * @param name
	 * @param address
	 * @param model
	 * @param itemName
	 * @param quantity
	 * @param price
	 */
	public Cart(String email, String name, String address, int model, String itemName, int quantity, float price) {
		super();
		this.email = email;
		this.name = name;
		this.address = address;
		this.model = model;
		this.itemName = itemName;
		this.quantity = quantity;
		this.price = price;
	}

	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", email=" + email + ", name=" + name + ", address=" + address + ", model="
				+ model + ", itemName=" + itemName + ", quantity=" + quantity + ", price=" + price + "]";
	}

}
