package com.shoppingBasket.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Invoice")
public class Invoice  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6244949459411943889L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="invoice_id", unique = true, nullable = false)
	private int invoiceId;
	@Column(name="name")
	private String name;
	@Column(name="email")
	private String email;
	@Column(name="address")
	private String address;
	@Column(name="item_name")
	private String itemName;
	@Column(name="sub_total")
	private Float subTotal;

	@Column(name="sub_tax")
	private Float subTax;

	
	public int getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(int invoiceId) {
		this.invoiceId = invoiceId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	
	
	public Float getSubTotal() {
		return subTotal;
	}
	public void setSubTotal(Float subTotal) {
		this.subTotal = subTotal;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Float getSubTax() {
		return subTax;
	}
	public void setSubTax(Float subTax) {
		this.subTax = subTax;
	}
	public Invoice() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param name
	 * @param email
	 * @param address
	 * @param itemName
	 * @param subTotal
	 * @param grandTotal
	 * @param subTax
	 * @param totalTax
	 */
	public Invoice(String name, String email, String address, String itemName, Float subTotal, 
			Float subTax) {
		super();
		this.name = name;
		this.email = email;
		this.address = address;
		this.itemName = itemName;
		this.subTotal = subTotal;
		this.subTax = subTax;
		}
	
	@Override
	public String toString() {
		return "Invoice [invoiceId=" + invoiceId + ", name=" + name + ", email=" + email + ", address=" + address
				+ ", itemName=" + itemName + ", subTotal=" + subTotal + ", subTax=" + subTax + "]";
	}
	
}
