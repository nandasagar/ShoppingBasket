package com.shoppingBasket.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.shoppingBasket.model.User;
import com.shoppingBasket.service.UserService;

@Controller
@SessionAttributes("User")
public class UserController {

	@ModelAttribute("User")
	public User setUp() {
		return new User();
	}

	@Autowired
	UserService userService;

	@PostMapping(path = "/loadUser")
	public ModelAndView registerUser(@ModelAttribute @Valid User user, Errors error, HttpServletRequest request,
			Model model) {

		if (error.hasErrors()) {
			ModelAndView mode = new ModelAndView("home");
			model.addAttribute("error", "Bad Data");
			return mode;
		}
		return userService.checkUser(user, request);
	}

	@GetMapping(path = "/home")
	public String homePage(User user, Model model) {
		model.addAttribute(new User());
		return "home";
	}
}
