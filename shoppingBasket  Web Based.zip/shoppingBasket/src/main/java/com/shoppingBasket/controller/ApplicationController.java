package com.shoppingBasket.controller;

import java.util.Objects;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.servlet.ModelAndView;
import com.shoppingBasket.model.Cart;
import com.shoppingBasket.model.Invoice;
import com.shoppingBasket.model.User;
import com.shoppingBasket.service.CartService;
import com.shoppingBasket.service.InvoiceService;
import com.shoppingBasket.service.ProductService;
/**
 * @author Nanda sagar
 *
 */
@Controller
@RequestMapping("/User")
public class ApplicationController {

	@Autowired
	private CartService cartService;
	@Autowired
	private InvoiceService invoiceService;
	@Autowired
	private ProductService productService;

	/**
	 * Fetching All Products from Database
	 * @param users
	 * @param user
	 * @param email
	 * @return
	 */
	@PostMapping("/getProducts")
	public ModelAndView getProducts(@SessionAttribute("User") User user,
			@RequestParam(value = "email", required = false) String email) {
		ModelAndView pageView = new ModelAndView("home");
		if (Objects.nonNull(user.getEmail()))
			email = user.getEmail();
		if (Objects.isNull(email))
			return pageView;
		else
			return productService.getAllProducts(user, email);
	}

	/**
	 * save cart Details Added by the User
	 * @param cart
	 * @param model
	 * @return
	 */
	@GetMapping("/saveToCart")
	public String saveCartDetail(Cart cart, Model model) {
		model.addAttribute(new Cart());
		return "cart";

	}

	/**
	 * @param cart
	 * @param model
	 * @param email
	 * @return
	 */
	@PostMapping("/saveToCart")
	public ModelAndView saveCartDetails(@ModelAttribute Cart cart, @RequestParam("model") int model,
			@RequestParam("email") String email) {
		return cartService.saveToCart(model, email);

	}

	/**
	 * Update quantity of the product based on User Choice
	 * @param cart
	 * @param error
	 * @param cartId
	 * @param user
	 * @return
	 */
	@PostMapping("/updateCart")
	public ModelAndView updateCart(@ModelAttribute @Valid Cart cart, Errors error, @RequestParam("cartId") int cartId,
			@SessionAttribute("User") User user) {
		if (error.hasErrors()) {
			return cartService.viewCart(cartId);
		}
		int quantity = cart.getQuantity();
		return cartService.updateCart(cartId, quantity);

	}

	/**
	 * Deleting the item from the Cart based on User Choice
	 * @param cart
	 * @param cartId
	 * @return
	 */
	@PostMapping("/removeCartItem")
	public ModelAndView removeCartItem(@ModelAttribute Cart cart, @RequestParam("cartId") int cartId) {
		return cartService.removeCartItem(cartId);
	}

	/**
	 * Fetching my cart details of the User
	 * @param cart
	 * @param user
	 * @param email
	 * @return
	 */
	@PostMapping("/myCart")
	public ModelAndView getMyCart(@ModelAttribute Cart cart, @SessionAttribute("User") User user,
			@RequestParam("email") String email) {
		return cartService.getMyCart(email);
	}

	/**
	 * Generating the Invoice Bill for the My cart Details 
	 * @param invoice
	 * @param cart
	 * @param user
	 * @param email
	 * @return
	 */
	@PostMapping("/generateInvoice")
	public ModelAndView generateInvoice(@ModelAttribute Invoice invoice, Cart cart, @SessionAttribute("User") User user,
			@RequestParam("email") String email) {
		return invoiceService.generateInvoice(email);
	}
}
