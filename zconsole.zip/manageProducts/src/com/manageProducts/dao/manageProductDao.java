package com.manageProducts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.manageProducts.domain.Products;
import com.manageProducts.domain.ViewTable;

public class manageProductDao {
	final static String url = "jdbc:mysql://localhost:3306/manageProducts?autoReconnect=true&useSSL=false";
	final static String user = "root";
	final static String pass = "Nanda$105";

	public static int insertProducts(Products product) throws SQLException {
		// TODO Auto-generated method stub
		Connection con = null;
		ResultSet rs = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, user, pass);
		} catch (ClassNotFoundException ex) {
			System.out.println("Exception caught while adding new products " + ex);
			ex.printStackTrace();
		}
		String sql = "insert into products " + "(name,price,description) values" + "( ?,?,?)";
		PreparedStatement pt = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

		pt.setString(1, product.getName());
		pt.setFloat(2, product.getPrice());
		pt.setString(3, product.getDescription());
		final int r = pt.executeUpdate();

		rs = pt.getGeneratedKeys();
		if (rs != null && rs.next()) {
			System.out.println();
			System.out.println();
			System.out.println("Congrats!! on Adding new product, product ID Generated : " + rs.getInt(1));
			System.out.println("**************************************");

		}

		con.close();
		return r;

	}

	public static void display(int viewProducts) throws SQLException {
		ResultSet rs = null;
		Connection con = null;
		try {

			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, user, pass);

			String sql = "select * from products where product_id = ?";
			PreparedStatement pt = con.prepareStatement(sql);
			pt.setInt(1, viewProducts);

			rs = pt.executeQuery();

			if (rs.next()) {
				// Retrieve by column name

				int pno = rs.getInt("Product_ID");
				String pname = rs.getString("Product_Name");
				float pamount = rs.getFloat("Product_Price");
				String description = rs.getString("Description");

				// Display values
				System.out.println("Product_ID   :     " + pno);
				System.out.println("Product_Name :     " + pname);
				System.out.println("Product_Price:     " + pamount);
				System.out.println("Description  :     " + description);

			} else {
				System.out.println("Invalid!! .Please Enter valid Policy No:");
			}
		} catch (Exception ex) {
			System.out.println(" Enter Valid Policy No");
		}

		finally {
			con.close();
		}

	}

	public static void displayMostViewed(int viewProducts) throws SQLException {
		ResultSet rs = null;
		Connection con = null;
		List<ViewTable> view = new ArrayList<>();
		List<Products> products = new ArrayList<>();
		List<ViewTable> listValue = new ArrayList<ViewTable>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, user, pass);
			Statement statement = con.createStatement();
			String sql = "select * from view_table";
				ResultSet resultSet = statement.executeQuery(sql);

			if (resultSet.next()) {
				int vc = resultSet.getInt("view_count");
				int pid = resultSet.getInt("product_id");
				ViewTable enity = new ViewTable(vc, pid);
				view.add(enity);
			}
			if (view.isEmpty()) {

			} else {
				Collections.sort(view);
				if (view.size() <= viewProducts) {
					String sql2 = "select * from products";
					ResultSet resultSet2 = statement.executeQuery(sql2);
					if (resultSet2.next()) {
						// Retrieve by column name

						int pno = resultSet2.getInt("Product_ID");
						String pname = resultSet2.getString("Product_Name");
						float pamount = resultSet2.getFloat("Product_Price");
						String description = resultSet2.getString("Description");
						Products product = new Products(pno, pname, pamount, description);
						products.add(product);

					}
					System.out.println(products);
				}

				int totalSize = view.size();
				int i = totalSize - 1;
				while (viewProducts != 0) {
					listValue.add(view.get(i));
					totalSize--;
					i--;
				}

				for (var iterate : listValue) {

					String sql3 = "select * from products where product_id = ?";
					PreparedStatement pt = con.prepareStatement(sql3);
					pt.setInt(1, iterate.getProductId());
					ResultSet rs3 = pt.executeQuery();

					if (rs3.next()) {
						int pno = rs3.getInt("Product_ID");
						String pname = rs3.getString("Product_Name");
						float pamount = rs3.getFloat("Product_Price");
						String description = rs3.getString("Description");
						Products product = new Products(pno, pname, pamount, description);
						products.add(product);
					}
					System.out.println(products);

				}
			}
		} catch (Exception ex) {
			System.out.println(" Enter Valid Policy No");
		}

		finally {
			con.close();
		}
	}

}