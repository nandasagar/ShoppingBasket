package com.manageProducts.domain;

/**
 * @author Nanda sagar
 *
 */
/* 
POJO Class  Products is used for increasing the readability and re-usability of a program.
It represents entity User which encapsulates Business Logic by providing Security. 
*/

public class ViewTable implements Comparable<Object>{

	private int viewCount;
	private int productId;
	
	
	
	public int getViewCount() {
		return viewCount;
	}


	public void setViewCount(int viewCount) {
		this.viewCount = viewCount;
	}


	public int getProductId() {
		return productId;
	}


	public void setProductId(int productId) {
		this.productId = productId;
	}

	

	/**
	 * 
	 */
	public ViewTable() {
		super();
		// TODO Auto-generated constructor stub
	}


	/**
	 * @param viewCount
	 * @param productId
	 */
	public ViewTable(int viewCount, int productId) {
		super();
		this.viewCount = viewCount;
		this.productId = productId;
	}


	@Override
	public String toString() {
		return "ViewTable [viewCount=" + viewCount + ", productId=" + productId + "]";
	}


	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		int  result = (this.getViewCount() < ((ViewTable) o).getViewCount() ? -1 : (this.getViewCount() == ((ViewTable) o).getViewCount() ? 0 : 1));
		 return result;
	}
	
	
	
}
