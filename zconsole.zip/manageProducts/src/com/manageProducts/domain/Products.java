package com.manageProducts.domain;

/**
 * @author Nanda sagar
 *
 */

/* 
    POJO Class  Products is used for increasing the readability and re-usability of a program.
    It represents entity User which encapsulates Business Logic by providing Security. 
 */
public class Products {

	private int productId;
	private String name;
	private float price;
	private String description;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * 
	 * @param productId 
	 * @param name
	 * @param price
	 * @param description
	 */
	public Products( String name, float price, String description) {
		super();
		this.name = name;
		this.price = price;
		this.description = description;
	}
	/**
	 * 
	 */
	public Products() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Products(int pno, String pname, float pamount, String description2) {
		super();
		this.productId=pno;
		this.name = pname;
		this.price = pamount;
		this.description = description2;
	}
	@Override
	public String toString() {
		return "Products [productId=" + productId + ", name=" + name + ", price=" + price + ", description="
				+ description + "]";
	}
	
	
	
	
	
}
