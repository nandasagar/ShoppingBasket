package com.manageProducts.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;

import com.manageProducts.dao.manageProductDao;
import com.manageProducts.domain.Products;

public class manageProductController {

	// StringBuffer in java is used to create modifiable String objects which is
	// given by user at Runtime.
	static InputStreamReader ir = new InputStreamReader(System.in);
	static BufferedReader br = new BufferedReader(ir);
	static String name;
	static String description;
	static float price;
	static int productId;
	static int size;
	static int viewCount;

	public static void main(String[] args) throws IOException {

		// the while loop will run forever as value is true. it can be terminated using
		// System.exit(0)
		while (true) {
			System.out.println("************Manage Products*****************");
			System.out.println("Enter The  Operations");
			System.out.println("1. Insert  new Product");
			System.out.println("2. Display a Product by productId ");
			System.out.println("3. Display most viewed Products");
			String x1 = br.readLine();
			try {
				int n = Integer.parseInt(x1);
				// switch statement is used for selection control mechanism
				switch (n) {
				case 1:
					insert();
					break;
				case 2:
					display();
					break;
				case 3:
					displayMostViewd();
					break;
				case 0:
					System.exit(0);
					break;
				default:
					System.out.print("Invalid No:");
				}
			} catch (Exception e) {
				System.out.println("Enter Valid Number");
			}
		}
	}

	private static void insert() throws Exception {

		// Creating product object and calling inputAll() method through UserInputs
		// object
		Products newProducts = inputAll();
		// on success returns an Int Value
		int res = manageProductDao.insertProducts(newProducts);

		if (res != 0) {
			System.out.println("Data Inserted!!");
			System.out.println();
		}
	}

	private static void displayMostViewd() throws SQLException {

		//Creating Users object and calling inputProductId() method through UserInputs object ui.
		int viewProducts=inputSize();
		//calling dao layer to call display method.
		manageProductDao.displayMostViewed(viewProducts);	
	}

	
	private static int inputSize() {
		try {
			System.out.println("How many products you whish to see (default is 5:");
			String x = br.readLine();
			size = Integer.parseInt(x);
			if(size==0)
				size=5;
		} catch (Exception e) {
			System.out.println("exception occured :" + e);
		}
		return size;
	}

	//------------------------
	private static void display() throws SQLException {
		System.out.println("Enter policy No to Fetch the Record");
		//Creating Users object and calling inputProductId() method through UserInputs object ui.
		int viewProducts=inputProductId();
		//calling dao layer to call display method.
		manageProductDao.display(viewProducts);	

	}
	
	private static int inputProductId() {
		try {
			System.out.println("Enter product ID:");
			String x = br.readLine();
			size = Integer.parseInt(x);
		} catch (Exception e) {
			System.out.println("exception occured :" + e);
		}
		return size;
	}
	//------------------------

	public static Products inputAll() {

		try {
			System.out.println("Enter product name:");
			name = br.readLine();
		} catch (Exception e) {
			System.out.println("exception occured :" + e);
		}
		try {
			System.out.println("Enter  product price :");
			String x = br.readLine();
			price = Float.parseFloat(x);
		} catch (Exception e) {
			System.out.println("exception occured :" + e);
		}

		try {
			System.out.println("Enter product description:");
			name = br.readLine();
		} catch (Exception e) {
			System.out.println("exception occured :" + e);
		}

		Products newProduct = new Products( name, price, description);
		return newProduct;

	}
}